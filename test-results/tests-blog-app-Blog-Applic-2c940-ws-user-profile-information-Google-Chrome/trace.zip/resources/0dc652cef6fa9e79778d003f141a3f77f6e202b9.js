(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/app_globals_0yg4wg8.css","static/chunks/node_modules_1p4irgs._.js","static/chunks/app_components_0p08i6x._.js","static/chunks/app_login_page_tsx_1wi-ux9._.js"],
    source: "entry"
});
